<?php

namespace Celmedia\Toyocosta\PirelliBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CelmediaToyocostaPirelliBundle extends Bundle
{
}
