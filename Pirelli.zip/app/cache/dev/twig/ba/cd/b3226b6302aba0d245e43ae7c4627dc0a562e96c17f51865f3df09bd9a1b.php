<?php

/* CelmediaToyocostaPirelliBundle:Pages:pirelli.html.twig */
class __TwigTemplate_bacdb3226b6302aba0d245e43ae7c4627dc0a562e96c17f51865f3df09bd9a1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "    ";
        $this->env->loadTemplate("CelmediaToyocostaPirelliBundle:Blocks:top.submenu.html.twig")->display($context);
        // line 2
        echo "
    <div class=\"row banner-pirelli\">

    </div>

    <div class=\"row buscador-pirelli\">
    \t<div class=\"form-group\">

    \t\t<div class=\"col-md-12\">
    \t\t\t<div class=\"form\">

    \t\t\t\t<div class=\"row\">
    \t\t\t\t\t<div class=\"col-md-1 bloque-vacio\">

    \t\t\t\t\t</div>
                        
    \t\t\t\t\t<div class=\"col-md-8\">
    \t\t\t\t\t
                          ";
        // line 20
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("CelmediaToyocostaPirelliBundle:Default:getFiltros", array("segmento" => (isset($context["tipo_llanta"]) ? $context["tipo_llanta"] : $this->getContext($context, "tipo_llanta")))));
        echo "

    \t\t\t\t\t</div>
                        <form name=\"buscador\" action=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("pirelli_buscador");
        echo "\" method=\"post\" >
    \t\t\t\t\t<div class=\"col-md-3\" style=\"padding-left: 0px;\">
                            <input type=\"hidden\"  name=\"categoria\" value=\"";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["tipo_llanta"]) ? $context["tipo_llanta"] : $this->getContext($context, "tipo_llanta")), "html", null, true);
        echo "\" />
    \t\t\t\t\t\t<input name=\"buscar\" class=\"form-control input-lg input-buscador input-search\" type=\"text\" placeholder=\"Buscar\">
    \t\t\t\t\t</div>
                        </form>
    \t\t\t\t</div>

    \t\t\t</div>
    \t\t</div>
    \t</div>


    </div>

    <div class=\"row banner-promocional\">

        <div class=\"col-md-10 col-md-offset-1\">
            <div class=\"row\">
                <ol class=\"breadcrumb\">
                  <li><a href=\"#\">HOME</a></li>
                  <li><a href=\"";
        // line 44
        echo $this->env->getExtension('routing')->getPath("pirelli_home");
        echo "\">PIRELLI</a></li>
                  <li class=\"active\">";
        // line 45
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, (isset($context["tipo_llanta"]) ? $context["tipo_llanta"] : $this->getContext($context, "tipo_llanta"))), "html", null, true);
        echo "</li>
                </ol>
            </div>
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"row\">
                        <div class=\"col-md-12 contenedor-centrar\">
                            <div class=\"banner\">
                                 ";
        // line 53
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "c17ebaf_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_c17ebaf_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/c17ebaf_pirelli-promocional_1.jpg");
            // line 54
            echo "                                <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"llanta\" class=\"img-responsive\" />
                                ";
        } else {
            // asset "c17ebaf"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_c17ebaf") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/c17ebaf.jpg");
            echo "                                <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"llanta\" class=\"img-responsive\" />
                                ";
        }
        unset($context["asset_url"]);
        // line 56
        echo "                            </div>

                        </div>  
                       
                    </div>
                </div>

            </div>
        </div>
    </div>


    ";
        // line 68
        $context["i"] = 0;
        // line 69
        echo "    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch((isset($context["llantas"]) ? $context["llantas"] : $this->getContext($context, "llantas")), 4));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 70
            echo "
        <div class=\"row bloque-llantas\" style=\"padding:0px; ";
            // line 71
            if (($this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "index") > 2)) {
                echo " display:none; ";
            }
            echo " \">

            <div class=\"col-md-10 col-md-offset-1\">
                <div class=\"row\">

                    ";
            // line 76
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")));
            foreach ($context['_seq'] as $context["_key"] => $context["llanta"]) {
                // line 77
                echo "                    <div class=\"col-md-3\">
                        <div class=\"row\">
                            <div class=\"col-md-10 fondo-ficha contenedor-centrar\">
                                <a id=\"llanta";
                // line 80
                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
                echo "\" data-toggle=\"modal\" href=\"#Modal_llanta";
                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
                echo "\">
                                <div class=\"row img-ficha\">
                                    ";
                // line 82
                if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
                    // asset "bdff3a8_0"
                    $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_bdff3a8_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/bdff3a8_llanta_1.jpg");
                    // line 83
                    echo "                                    <img src=\"";
                    echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
                    echo "\" alt=\"llanta\" class=\"img-responsive\" />
                                    ";
                } else {
                    // asset "bdff3a8"
                    $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_bdff3a8") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/bdff3a8.jpg");
                    echo "                                    <img src=\"";
                    echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
                    echo "\" alt=\"llanta\" class=\"img-responsive\" />
                                    ";
                }
                unset($context["asset_url"]);
                // line 85
                echo "                                </div>
                                </a>
                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <h2 class=\"text-modelo\">
                                        ";
                // line 90
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "modelo"), "html", null, true);
                echo "
                                        </h2>
                                    </div>
                                </div>
                                <div class=\"row\">
                                    <div class=\"col-md-6\">
                                        <p class=\"text-tipo\">";
                // line 96
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "segmento"), "html", null, true);
                echo "</p>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <p class=\"text-precio\">\$";
                // line 99
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "precio"), "html", null, true);
                echo "</p>
                                    </div>
                                </div>
                                <div class=\"divisor\"></div>
                                <div class=\"row margin-detalle\">
                                    <div class=\"col-md-6\">
                                        <p class=\"text-detalle\">Rin</p>
                                        <p class=\"text-detalle\">Medida</p>
                                        <p class=\"text-detalle\">Linea</p>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <p class=\"text-detalle\">";
                // line 110
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "rin"), "html", null, true);
                echo "</p>
                                        <p class=\"text-detalle\">";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "medida"), "html", null, true);
                echo "</p>
                                        <p class=\"text-detalle\">";
                // line 112
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "linea"), "html", null, true);
                echo "</p>
                                    </div>
                                </div>

                            </div>

                            <!-- Modal -->
                            <div class=\"modal fade\" id=\"Modal_llanta";
                // line 119
                echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")), "html", null, true);
                echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">
                                <div class=\"modal-dialog\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-header header-ficha\">
                                            <button type=\"button\" class=\"close close-ficha\" data-dismiss=\"modal\" aria-hidden=\"true\"></button>
                                        </div>
                                        <div class=\"modal-body body-ficha\" style=\"padding-top: 0px;padding-bottom: 0px;\">
                                            <div class=\"row fondo-ficha\">
                                                <div class=\"col-md-6\">
                                                    <p class=\"modal-text-tipo\">";
                // line 128
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "modelo"), "html", null, true);
                echo "</p>
                                                </div>
                                                <div class=\"col-md-6 text-right\">
                                                    <p class=\"modal-text-precio\">\$";
                // line 131
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "precio"), "html", null, true);
                echo "</p>
                                                </div>
                                            </div>
                                            <div class=\"row\">
                                                ";
                // line 135
                if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
                    // asset "4b3fede_0"
                    $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_4b3fede_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/4b3fede_llanta-lightbox_1.png");
                    // line 136
                    echo "                                                <img src=\"";
                    echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
                    echo "\" alt=\"llanta\" class=\"img-responsive contenedor-centrar\" />
                                                ";
                } else {
                    // asset "4b3fede"
                    $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_4b3fede") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/4b3fede.png");
                    echo "                                                <img src=\"";
                    echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
                    echo "\" alt=\"llanta\" class=\"img-responsive contenedor-centrar\" />
                                                ";
                }
                unset($context["asset_url"]);
                // line 138
                echo "
                                            </div>
                                            <div class=\"row fondo-ficha\">

                                                <div class=\"col-md-12 modal-descripcion\">
                                                    <div class=\"row\">
                                                        <div class=\"col-md-6\">
                                                            <p class=\"modal-text\">Medida:</p>
                                                        </div>
                                                        <div class=\"col-md-6 text-right\">
                                                            <p class=\"modal-text-desc\">";
                // line 148
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "medida"), "html", null, true);
                echo "</p>
                                                        </div>

                                                    </div>
                                                    <div class=\"modal-divisor\"></div>
                                                    <div class=\"row\">
                                                        <div class=\"col-md-6\">
                                                            <p class=\"modal-text\">Rin:</p>
                                                        </div>
                                                        <div class=\"col-md-6 text-right\">
                                                            <p class=\"modal-text-desc\">";
                // line 158
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "rin"), "html", null, true);
                echo "</p>
                                                        </div>

                                                    </div>
                                                    <div class=\"modal-divisor\"></div>
                                                    <div class=\"row\">
                                                        <div class=\"col-md-6\">
                                                            <p class=\"modal-text\">Diseño:</p>
                                                        </div>
                                                        <div class=\"col-md-6 text-right\">
                                                            <p class=\"modal-text-desc\">";
                // line 168
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "diseno"), "html", null, true);
                echo "</p>
                                                        </div>

                                                    </div>
                                                    <div class=\"modal-divisor\"></div>
                                                    <div class=\"row\">
                                                        <div class=\"col-md-6\">
                                                            <p class=\"modal-text\">Segmento:</p>
                                                        </div>
                                                        <div class=\"col-md-6 text-right\">
                                                            <p class=\"modal-text-desc\">";
                // line 178
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "segmento"), "html", null, true);
                echo "</p>
                                                        </div>

                                                    </div>
                                                    <div class=\"modal-divisor\"></div>
                                                    <div class=\"row\">
                                                        <div class=\"col-md-6\">
                                                            <p class=\"modal-text\">Linea:</p>
                                                        </div>
                                                        <div class=\"col-md-6 text-right\">
                                                            <p class=\"modal-text-desc\">";
                // line 188
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["llanta"]) ? $context["llanta"] : $this->getContext($context, "llanta")), "linea"), "html", null, true);
                echo "</p>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class=\"col-md-12 modal-botones\">
                                                    <div class=\"col-md-5 btn btn-descarga\">Descargar Cat&aacute;logo</div>
                                                    <div class=\"col-md-5 col-md-offset-2 btn btn-info\">M&aacute;s informaci&oacute;n</div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    ";
                // line 207
                $context["i"] = ((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) + 1);
                // line 208
                echo "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['llanta'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 209
            echo "
                </div>
            </div>


        </div>   

    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 217
        echo "

    ";
        // line 219
        if ((twig_length_filter($this->env, (isset($context["llantas"]) ? $context["llantas"] : $this->getContext($context, "llantas"))) > 8)) {
            echo " 
        
        <div class=\"row\" style=\"margin-bottom:20px;\">
            <div class=\"container\">

                <div class=\"col-md-4 col-md-offset-4 btn btn-ver\" onclick=\"mostrarLlantas();\">
                    Ver m&aacute;s
                </div>
            </div>
        </div>

    ";
        } else {
            // line 231
            echo "        

        <div class=\"row\" style=\"margin-bottom:20px;\">
            <div class=\"container\">

            </div>
        </div>

    ";
        }
        // line 239
        echo " 



";
    }

    public function getTemplateName()
    {
        return "CelmediaToyocostaPirelliBundle:Pages:pirelli.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  431 => 239,  420 => 231,  405 => 219,  401 => 217,  380 => 209,  374 => 208,  372 => 207,  350 => 188,  337 => 178,  324 => 168,  311 => 158,  298 => 148,  286 => 138,  272 => 136,  268 => 135,  261 => 131,  255 => 128,  243 => 119,  233 => 112,  229 => 111,  225 => 110,  211 => 99,  205 => 96,  196 => 90,  189 => 85,  175 => 83,  171 => 82,  164 => 80,  159 => 77,  155 => 76,  145 => 71,  142 => 70,  124 => 69,  122 => 68,  108 => 56,  94 => 54,  90 => 53,  79 => 45,  75 => 44,  53 => 25,  48 => 23,  42 => 20,  22 => 2,  80 => 45,  66 => 43,  62 => 42,  135 => 44,  103 => 43,  98 => 37,  96 => 36,  87 => 29,  84 => 28,  82 => 27,  74 => 21,  36 => 19,  32 => 12,  19 => 1,);
    }
}
