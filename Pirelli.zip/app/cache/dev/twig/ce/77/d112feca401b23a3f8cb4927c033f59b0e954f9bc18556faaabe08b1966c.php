<?php

/* CelmediaToyocostaPirelliBundle::layout.html.twig */
class __TwigTemplate_ce77d112feca401b23a3f8cb4927c033f59b0e954f9bc18556faaabe08b1966c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">
        <!-- <link rel=\"shortcut icon\" href=\"../../assets/ico/favicon.ico\"> -->
        <title>Toyocosta</title>

    ";
        // line 12
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "ca9947f_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ca9947f_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/ca9947f_bootstrap.min_1.css");
            // line 19
            echo "        <link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
            // asset "ca9947f_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ca9947f_1") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/ca9947f_menu.toyocosta_2.css");
            echo "        <link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
            // asset "ca9947f_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ca9947f_2") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/ca9947f_jquery.selectbox_3.css");
            echo "        <link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
            // asset "ca9947f_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ca9947f_3") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/ca9947f_reset_4.css");
            echo "        <link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
            // asset "ca9947f_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ca9947f_4") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/ca9947f_estilo.pirelli_5.css");
            echo "        <link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "ca9947f"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_ca9947f") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/ca9947f.css");
            echo "        <link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        // line 21
        echo "    </head>

    <body>



    ";
        // line 27
        $this->env->loadTemplate("CelmediaToyocostaPirelliBundle:Blocks:top.menu.html.twig")->display($context);
        // line 28
        echo "    ";
        $this->env->loadTemplate("CelmediaToyocostaPirelliBundle:Pages:pirelli.html.twig")->display($context);
        // line 29
        echo "






    ";
        // line 36
        $this->env->loadTemplate("CelmediaToyocostaPirelliBundle:Blocks:footer.html.twig")->display($context);
        // line 37
        echo "     ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "06490c7_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_06490c7_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/06490c7_jquery_1.js");
            // line 43
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
     ";
            // asset "06490c7_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_06490c7_1") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/06490c7_jquery.selectbox-0.2_2.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
     ";
            // asset "06490c7_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_06490c7_2") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/06490c7_script_3.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
     ";
            // asset "06490c7_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_06490c7_3") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/06490c7_bootstrap.min_4.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
     ";
        } else {
            // asset "06490c7"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_06490c7") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/06490c7.js");
            echo "        <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
     ";
        }
        unset($context["asset_url"]);
        // line 44
        echo "                          
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "CelmediaToyocostaPirelliBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 44,  103 => 43,  98 => 37,  96 => 36,  87 => 29,  84 => 28,  82 => 27,  74 => 21,  36 => 19,  32 => 12,  19 => 1,);
    }
}
