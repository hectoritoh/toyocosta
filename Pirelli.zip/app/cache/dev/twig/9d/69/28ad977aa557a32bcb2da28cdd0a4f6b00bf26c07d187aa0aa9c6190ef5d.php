<?php

/* @WebProfiler/Profiler/base_js.html.twig */
class __TwigTemplate_9d6928ad977aa557a32bcb2da28cdd0a4f6b00bf26c07d187aa0aa9c6190ef5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<script>/*<![CDATA[*/
    Sfjs = (function() {
        \"use strict\";

        var noop = function() {},

            profilerStorageKey = 'sf2/profiler/',

            request = function(url, onSuccess, onError, payload, options) {
                var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                options = options || {};
                xhr.open(options.method || 'GET', url, true);
                xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                xhr.onreadystatechange = function(state) {
                    if (4 === xhr.readyState && 200 === xhr.status) {
                        (onSuccess || noop)(xhr);
                    } else if (4 === xhr.readyState && xhr.status != 200) {
                        (onError || noop)(xhr);
                    }
                };
                xhr.send(payload || '');
            },

            hasClass = function(el, klass) {
                return el.className.match(new RegExp('\\\\b' + klass + '\\\\b'));
            },

            removeClass = function(el, klass) {
                el.className = el.className.replace(new RegExp('\\\\b' + klass + '\\\\b'), ' ');
            },

            addClass = function(el, klass) {
                if (!hasClass(el, klass)) { el.className += \" \" + klass; }
            },

            getPreference = function(name) {
                if (!window.localStorage) {
                    return null;
                }

                return localStorage.getItem(profilerStorageKey + name);
            },

            setPreference = function(name, value) {
                if (!window.localStorage) {
                    return null;
                }

                localStorage.setItem(profilerStorageKey + name, value);
            };

        return {
            hasClass: hasClass,

            removeClass: removeClass,

            addClass: addClass,

            getPreference: getPreference,

            setPreference: setPreference,

            request: request,

            load: function(selector, url, onSuccess, onError, options) {
                var el = document.getElementById(selector);

                if (el && el.getAttribute('data-sfurl') !== url) {
                    request(
                        url,
                        function(xhr) {
                            el.innerHTML = xhr.responseText;
                            el.setAttribute('data-sfurl', url);
                            removeClass(el, 'loading');
                            (onSuccess || noop)(xhr, el);
                        },
                        function(xhr) { (onError || noop)(xhr, el); },
                        options
                    );
                }

                return this;
            },

            toggle: function(selector, elOn, elOff) {
                var i,
                    style,
                    tmp = elOn.style.display,
                    el = document.getElementById(selector);

                elOn.style.display = elOff.style.display;
                elOff.style.display = tmp;

                if (el) {
                    el.style.display = 'none' === tmp ? 'none' : 'block';
                }

                return this;
            }
        }
    })();
/*]]>*/</script>
";
    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/base_js.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  83 => 30,  70 => 26,  50 => 15,  46 => 14,  30 => 5,  26 => 3,  117 => 65,  99 => 62,  95 => 60,  77 => 57,  120 => 41,  109 => 39,  105 => 38,  81 => 58,  72 => 21,  61 => 19,  57 => 18,  33 => 8,  24 => 2,  102 => 36,  91 => 35,  85 => 29,  69 => 27,  63 => 26,  55 => 20,  41 => 18,  37 => 9,  431 => 239,  420 => 231,  405 => 219,  401 => 217,  380 => 209,  374 => 208,  372 => 207,  350 => 188,  337 => 178,  324 => 168,  311 => 158,  298 => 148,  286 => 138,  272 => 136,  268 => 135,  261 => 131,  255 => 128,  243 => 119,  233 => 112,  229 => 111,  225 => 110,  211 => 99,  205 => 96,  196 => 90,  189 => 85,  175 => 83,  171 => 82,  164 => 80,  159 => 77,  155 => 76,  145 => 71,  142 => 70,  124 => 69,  122 => 68,  108 => 56,  94 => 54,  90 => 53,  79 => 29,  75 => 28,  53 => 25,  48 => 11,  42 => 12,  22 => 2,  80 => 30,  66 => 25,  62 => 24,  135 => 44,  103 => 63,  98 => 37,  96 => 31,  87 => 29,  84 => 28,  82 => 27,  74 => 29,  36 => 19,  32 => 6,  19 => 1,);
    }
}
