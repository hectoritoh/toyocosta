<?php

/* CelmediaToyocostaPirelliBundle:Blocks:footer.html.twig */
class __TwigTemplate_e959ab39d873cf12d4aca36cd5e1a4a50bb689f3fe0363db3836c773be49b583 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"footer\">
\t<div class=\"container\" style=\"padding-top:20px;\">
\t\t<div class=\"row\" style=\"padding-top: 10px;padding-bottom: 10px;\">
\t\t\t<div class=\"col-md-3 pull-left\">
\t\t\t\t<p class=\"text-footer\">Empresa</p>
\t\t\t\t<p class=\"links-footer\"><a href=\"#\">Quienes Somos</a><br />
\t\t\t\t<a href=\"#\">Test Drive</a><br />
\t\t\t\t<a href=\"#\">Certificado Toyocosta</a></p>
\t\t\t</div>
\t\t\t<div class=\"col-md-3 pull-left\">
\t\t\t\t<p class=\"text-footer\">Productos</p>
\t\t\t\t<p class=\"links-footer\">Autos<br />
\t\t\t\t<a href=\"#\">Camionetas</a><br />
\t\t\t\t<a href=\"#\">Suv</a><br />
\t\t\t\t<a href=\"#\">H&iacute;bridos</a><br />
\t\t\t\t<a href=\"#\">Montacargas</a><br />
\t\t\t\t<a href=\"#\">Pilleri</a><br />
\t\t\t\t<a href=\"#\">Seminuevos</a></p>
\t\t\t</div>
\t\t\t<div class=\"col-md-3 pull-left\">
\t\t\t\t<p class=\"text-footer\">Servicios</p>
\t\t\t\t<p  class=\"links-footer\">
\t\t\t\t<a href=\"#\">Repuestos y Accesorios</a><br />
\t\t\t\t<a href=\"#\">Citas de Mantenimiento</a></p>
\t\t\t</div>
\t\t\t<div class=\"col-md-3 pull-left\">
\t\t\t\t<p class=\"text-footer\">Redes Sociales</p>
\t\t\t\t<div class=\"face-icon\">
\t\t\t\t\t<p class=\"links-footer\" style=\"padding-left: 32px;\">
\t\t\t\t\t\t<a href=\"http://www.facebook.com/toyocosta\">Hazte Fan</a>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t\t<div class=\"tweet-icon\">
\t\t\t\t\t<p class=\"links-footer\" style=\"padding-left: 32px;\">
\t\t\t\t\t\t<a href=\"http://twitter.com/toyocosta\">Siguenos</a>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t\t<div class=\"blog-icon\">
\t\t\t\t\t<p class=\"links-footer\" style=\"padding-left: 32px;\">
\t\t\t\t\t\t<a href=\"http://www.toyocosta.com/blog/\">Blog</a>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"row\" style=\"padding-bottom:15px;\">
\t\t\t<h1 class=\"copy-footer\" style=\"margin-top:0px;margin-bottom:35px;\">COPYRIGHT @2014 TOYOCOSTA ALL RIGHTS RESERVED</h1>
\t\t</div>
\t</div>
</div>

<div class=\"banners-foot navbar-fixed-bottom\">
\t
\t<div class=\"container\">
\t\t<div style=\"cursor:pointer;\" class=\"col-md-2\" onclick=\"mostrarBanners();\">

\t\t\t<div id=\"mas\">
\t\t\t\t";
        // line 57
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "fe7c180_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_fe7c180_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/fe7c180_mas_1.png");
            // line 58
            echo "\t\t\t\t<img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"\" class=\"\"/>
\t\t        ";
        } else {
            // asset "fe7c180"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_fe7c180") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/fe7c180.png");
            echo "\t\t\t\t<img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"\" class=\"\"/>
\t\t        ";
        }
        unset($context["asset_url"]);
        // line 60
        echo "\t\t\t</div>
\t\t\t<div id=\"cerrar\" style=\"display:none;\">
\t\t\t\t";
        // line 62
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "6c29613_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_6c29613_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/6c29613_cerrar_1.png");
            // line 63
            echo "\t\t\t\t<img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"\" class=\"\"/>
\t\t        ";
        } else {
            // asset "6c29613"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_6c29613") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/6c29613.png");
            echo "\t\t\t\t<img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"\" class=\"\"/>
\t\t        ";
        }
        unset($context["asset_url"]);
        // line 65
        echo "\t\t\t</div>

\t\t</div>

\t</div>
\t<div id=\"banners\" class=\"row footer-banners border-rojo\">

\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t<a href=\"#\"><div class=\"exonerados-footer\"></div></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t<a href=\"#\"><div class=\"cita-footer\"></div></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t<a href=\"#\"><div class=\"avaluo-footer\"></div></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t<a href=\"#\"><div class=\"montacargas-footer\"></div></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t<a href=\"#\"><div class=\"seminuevos-footer\"></div></a>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<!-- <div class=\"row text-center\">
\t\t\t\t<h4 class=\"text-banner-footer\">&#169; www.toyocosta.com 2011 &#108; Todos los derechos reservados</h4>
\t\t\t</div> -->
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "CelmediaToyocostaPirelliBundle:Blocks:footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 65,  99 => 62,  95 => 60,  77 => 57,  120 => 41,  109 => 39,  105 => 38,  81 => 58,  72 => 21,  61 => 19,  57 => 18,  33 => 8,  24 => 2,  102 => 36,  91 => 33,  85 => 29,  69 => 27,  63 => 26,  55 => 20,  41 => 18,  37 => 9,  431 => 239,  420 => 231,  405 => 219,  401 => 217,  380 => 209,  374 => 208,  372 => 207,  350 => 188,  337 => 178,  324 => 168,  311 => 158,  298 => 148,  286 => 138,  272 => 136,  268 => 135,  261 => 131,  255 => 128,  243 => 119,  233 => 112,  229 => 111,  225 => 110,  211 => 99,  205 => 96,  196 => 90,  189 => 85,  175 => 83,  171 => 82,  164 => 80,  159 => 77,  155 => 76,  145 => 71,  142 => 70,  124 => 69,  122 => 68,  108 => 56,  94 => 54,  90 => 53,  79 => 45,  75 => 44,  53 => 25,  48 => 11,  42 => 20,  22 => 2,  80 => 30,  66 => 43,  62 => 42,  135 => 44,  103 => 63,  98 => 37,  96 => 31,  87 => 29,  84 => 28,  82 => 27,  74 => 29,  36 => 19,  32 => 12,  19 => 1,);
    }
}
