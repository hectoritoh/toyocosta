<?php

/* CelmediaToyocostaPirelliBundle:Blocks:top.submenu.html.twig */
class __TwigTemplate_6030103e2fd763d658a53b356203324f525bab90ae53666d9080d3e6e0e49625 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"alto-pirelli\">
  
</div>
<div class=\"submenu\">
  
    <nav class=\"navbar navbar-default nav-pirelli\" role=\"navigation\">
      <div class=\"container\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"#\" style=\"padding-top:0px;\">
            ";
        // line 17
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "bcd6fa0_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_bcd6fa0_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/bcd6fa0_pirelli_1.jpg");
            // line 18
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"llanta\" class=\"img-responsive\" />
            ";
        } else {
            // asset "bcd6fa0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_bcd6fa0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/bcd6fa0.jpg");
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"llanta\" class=\"img-responsive\" />
            ";
        }
        unset($context["asset_url"]);
        // line 20
        echo "          </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
          <ul class=\"nav navbar-nav\" id=\"nav-list-pirelli\">
            <li  ";
        // line 26
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "get", array(0 => "_route"), "method") == "pirelli_home")) {
            echo " class=\"active\" ";
        }
        echo "   >           
              <a href=\"";
        // line 27
        echo $this->env->getExtension('routing')->getPath("pirelli_home");
        echo "\">LLANTAS AUTO</a>
            </li>
            <li  ";
        // line 29
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "get", array(0 => "_route"), "method") == "pirelli_camioneta")) {
            echo "  class=\"active\"  ";
        }
        echo "   >
              <a href=\"";
        // line 30
        echo $this->env->getExtension('routing')->getPath("pirelli_camioneta");
        echo "\">LLANTAS CAMIONETA</a>
            </li>
            <li  ";
        // line 32
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "get", array(0 => "_route"), "method") == "pirelli_suv")) {
            echo "  class=\"active\"  ";
        }
        echo "  >
              <a href=\"";
        // line 33
        echo $this->env->getExtension('routing')->getPath("pirelli_suv");
        echo "\">LLANTAS SUV</a>
            </li>
            <li  ";
        // line 35
        if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "get", array(0 => "_route"), "method") == "pirelli_industrial")) {
            echo "  class=\"active\"  ";
        }
        echo " >
              <a href=\"";
        // line 36
        echo $this->env->getExtension('routing')->getPath("pirelli_industrial");
        echo "\">LLANTAS INDUSTRIAL</a>
            </li>
            <li><a href=\"\">SUBDISTRIBUIDORES</a></li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>


</div>";
    }

    public function getTemplateName()
    {
        return "CelmediaToyocostaPirelliBundle:Blocks:top.submenu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 36,  91 => 33,  85 => 32,  69 => 27,  63 => 26,  55 => 20,  41 => 18,  37 => 17,  431 => 239,  420 => 231,  405 => 219,  401 => 217,  380 => 209,  374 => 208,  372 => 207,  350 => 188,  337 => 178,  324 => 168,  311 => 158,  298 => 148,  286 => 138,  272 => 136,  268 => 135,  261 => 131,  255 => 128,  243 => 119,  233 => 112,  229 => 111,  225 => 110,  211 => 99,  205 => 96,  196 => 90,  189 => 85,  175 => 83,  171 => 82,  164 => 80,  159 => 77,  155 => 76,  145 => 71,  142 => 70,  124 => 69,  122 => 68,  108 => 56,  94 => 54,  90 => 53,  79 => 45,  75 => 44,  53 => 25,  48 => 23,  42 => 20,  22 => 2,  80 => 30,  66 => 43,  62 => 42,  135 => 44,  103 => 43,  98 => 37,  96 => 35,  87 => 29,  84 => 28,  82 => 27,  74 => 29,  36 => 19,  32 => 12,  19 => 1,);
    }
}
