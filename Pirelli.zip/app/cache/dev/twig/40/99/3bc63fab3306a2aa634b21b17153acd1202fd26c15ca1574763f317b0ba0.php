<?php

/* SonataAdminBundle:CRUD:batch_confirmation.html.twig */
class __TwigTemplate_40993bc63fab3306a2aa634b21b17153acd1202fd26c15ca1574763f317b0ba0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'actions' => array($this, 'block_actions'),
            'side_menu' => array($this, 'block_side_menu'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return $this->env->resolveTemplate((isset($context["base_template"]) ? $context["base_template"] : $this->getContext($context, "base_template")));
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_actions($context, array $blocks = array())
    {
        // line 15
        echo "    <div class=\"sonata-actions btn-group\">
        ";
        // line 16
        $this->env->loadTemplate("SonataAdminBundle:Button:list_button.html.twig")->display($context);
        // line 17
        echo "        ";
        $this->env->loadTemplate("SonataAdminBundle:Button:create_button.html.twig")->display($context);
        // line 18
        echo "    </div>
";
    }

    // line 21
    public function block_side_menu($context, array $blocks = array())
    {
        echo $this->env->getExtension('knp_menu')->render($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "sidemenu", array(0 => (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action"))), "method"), array("currentClass" => "active"), "list");
    }

    // line 23
    public function block_content($context, array $blocks = array())
    {
        // line 24
        echo "    <div class=\"sonata-ba-delete\">
        <h1>";
        // line 25
        echo $this->env->getExtension('translator')->getTranslator()->trans("title_batch_confirmation", array("%action%" => (isset($context["action_label"]) ? $context["action_label"] : $this->getContext($context, "action_label"))), "SonataAdminBundle");
        echo "</h1>

        ";
        // line 27
        if ($this->getAttribute((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")), "all_elements")) {
            // line 28
            echo "            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("message_batch_all_confirmation", array(), "SonataAdminBundle"), "html", null, true);
            echo "
        ";
        } else {
            // line 30
            echo "            ";
            echo $this->env->getExtension('translator')->getTranslator()->transChoice("message_batch_confirmation", twig_length_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")), "idx")), array("%count%" => twig_length_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")), "idx"))), "SonataAdminBundle");
            // line 31
            echo "        ";
        }
        // line 32
        echo "
        <div class=\"well well-small form-actions\">
            <form action=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "batch", 1 => array("filter" => $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "filterParameters"))), "method"), "html", null, true);
        echo "\" method=\"POST\" >
                <input type=\"hidden\" name=\"confirmation\" value=\"ok\">
                <input type=\"hidden\" name=\"data\" value=\"";
        // line 36
        echo twig_escape_filter($this->env, twig_jsonencode_filter((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data"))), "html", null, true);
        echo "\">
                <input type=\"hidden\" name=\"_sonata_csrf_token\" value=\"";
        // line 37
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\">

                <div style=\"display: none\">
                    ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "
                </div>

                <button type=\"submit\" class=\"btn btn-danger\">";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("btn_execute_batch_action", array(), "SonataAdminBundle"), "html", null, true);
        echo "</button>

                ";
        // line 45
        if (($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "hasRoute", array(0 => "list"), "method") && $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "isGranted", array(0 => "LIST"), "method"))) {
            // line 46
            echo "                    ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("delete_or", array(), "SonataAdminBundle"), "html", null, true);
            echo "

                    <a class=\"btn btn-success\" href=\"";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "list"), "method"), "html", null, true);
            echo "\">
                        <i class=\"icon-th-list icon-white\"></i> ";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("link_action_list", array(), "SonataAdminBundle"), "html", null, true);
            echo "
                    </a>
                ";
        }
        // line 52
        echo "            </form>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:batch_confirmation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  598 => 188,  590 => 185,  562 => 173,  558 => 172,  552 => 171,  549 => 170,  545 => 169,  540 => 167,  528 => 163,  515 => 160,  510 => 154,  503 => 140,  493 => 137,  455 => 104,  447 => 102,  442 => 101,  418 => 114,  401 => 86,  394 => 137,  382 => 128,  334 => 121,  320 => 116,  307 => 82,  195 => 54,  12 => 34,  389 => 103,  377 => 99,  349 => 90,  332 => 85,  324 => 82,  287 => 68,  282 => 66,  276 => 64,  234 => 48,  231 => 47,  218 => 59,  857 => 274,  854 => 273,  849 => 268,  845 => 266,  839 => 263,  836 => 262,  834 => 261,  829 => 259,  821 => 258,  818 => 257,  816 => 256,  813 => 255,  807 => 253,  805 => 252,  802 => 251,  796 => 249,  794 => 248,  791 => 247,  785 => 245,  783 => 244,  780 => 243,  774 => 241,  772 => 240,  769 => 239,  766 => 238,  762 => 221,  757 => 218,  751 => 216,  748 => 215,  745 => 214,  731 => 213,  725 => 211,  720 => 208,  714 => 206,  706 => 204,  698 => 201,  677 => 199,  675 => 198,  671 => 196,  665 => 194,  661 => 191,  655 => 189,  651 => 280,  644 => 270,  642 => 238,  638 => 237,  635 => 236,  629 => 233,  626 => 232,  624 => 231,  619 => 228,  613 => 191,  608 => 223,  603 => 194,  596 => 189,  588 => 179,  584 => 174,  575 => 170,  569 => 168,  566 => 167,  563 => 166,  521 => 162,  501 => 147,  498 => 146,  491 => 145,  488 => 144,  485 => 129,  482 => 128,  476 => 141,  473 => 140,  467 => 137,  460 => 136,  451 => 103,  431 => 129,  419 => 164,  416 => 163,  404 => 87,  392 => 104,  378 => 117,  367 => 180,  357 => 125,  350 => 117,  330 => 105,  317 => 86,  297 => 77,  710 => 213,  704 => 203,  701 => 202,  699 => 208,  693 => 205,  683 => 204,  666 => 200,  660 => 198,  652 => 193,  649 => 273,  632 => 190,  615 => 189,  610 => 224,  605 => 222,  602 => 189,  593 => 188,  589 => 178,  587 => 177,  582 => 176,  565 => 174,  544 => 160,  539 => 157,  536 => 170,  533 => 165,  530 => 168,  527 => 167,  522 => 165,  507 => 157,  495 => 133,  477 => 111,  470 => 139,  464 => 147,  459 => 145,  450 => 141,  425 => 175,  411 => 129,  406 => 123,  400 => 120,  397 => 119,  395 => 118,  385 => 116,  371 => 182,  352 => 91,  344 => 101,  339 => 100,  336 => 99,  333 => 98,  329 => 120,  266 => 66,  244 => 65,  205 => 38,  200 => 55,  188 => 49,  178 => 28,  118 => 49,  306 => 141,  303 => 140,  300 => 78,  286 => 80,  280 => 131,  274 => 68,  263 => 55,  236 => 109,  216 => 42,  70 => 23,  553 => 162,  548 => 173,  541 => 180,  537 => 178,  525 => 166,  520 => 170,  516 => 169,  513 => 160,  511 => 167,  506 => 141,  502 => 155,  499 => 139,  496 => 138,  489 => 130,  483 => 129,  479 => 153,  475 => 152,  462 => 108,  448 => 133,  421 => 126,  414 => 122,  408 => 119,  403 => 117,  399 => 124,  391 => 117,  388 => 133,  386 => 119,  375 => 106,  372 => 105,  354 => 92,  348 => 100,  342 => 88,  325 => 93,  313 => 90,  310 => 80,  308 => 88,  302 => 73,  296 => 77,  292 => 135,  255 => 71,  184 => 30,  155 => 38,  146 => 47,  126 => 48,  170 => 55,  694 => 412,  685 => 406,  680 => 200,  678 => 202,  668 => 195,  663 => 199,  658 => 190,  654 => 389,  647 => 382,  643 => 381,  637 => 378,  633 => 377,  627 => 374,  617 => 367,  609 => 362,  599 => 192,  592 => 351,  585 => 183,  581 => 345,  579 => 181,  577 => 180,  571 => 176,  567 => 337,  557 => 163,  550 => 161,  542 => 321,  538 => 319,  531 => 175,  526 => 310,  518 => 161,  514 => 152,  509 => 150,  504 => 148,  492 => 295,  486 => 292,  481 => 290,  466 => 109,  456 => 273,  452 => 272,  445 => 267,  443 => 132,  439 => 100,  429 => 255,  424 => 88,  422 => 134,  420 => 127,  415 => 113,  396 => 142,  383 => 101,  366 => 210,  361 => 208,  346 => 102,  335 => 86,  331 => 187,  326 => 83,  304 => 81,  291 => 75,  272 => 158,  267 => 156,  242 => 59,  152 => 38,  114 => 44,  104 => 43,  194 => 53,  186 => 51,  181 => 29,  161 => 71,  58 => 22,  124 => 52,  321 => 91,  318 => 80,  316 => 89,  288 => 81,  284 => 67,  279 => 65,  275 => 73,  256 => 61,  250 => 60,  237 => 64,  232 => 136,  222 => 81,  215 => 78,  191 => 69,  153 => 49,  150 => 27,  110 => 145,  76 => 35,  358 => 106,  351 => 122,  347 => 134,  343 => 115,  338 => 130,  327 => 119,  323 => 117,  319 => 92,  315 => 79,  301 => 80,  299 => 72,  293 => 70,  289 => 74,  281 => 75,  277 => 78,  271 => 59,  265 => 126,  262 => 105,  260 => 63,  257 => 149,  251 => 67,  248 => 116,  239 => 97,  228 => 52,  225 => 58,  213 => 126,  211 => 81,  197 => 54,  174 => 47,  148 => 35,  134 => 45,  127 => 76,  20 => 11,  270 => 67,  253 => 148,  233 => 62,  212 => 74,  210 => 75,  206 => 58,  202 => 77,  198 => 55,  192 => 53,  185 => 86,  180 => 49,  175 => 33,  172 => 46,  167 => 48,  165 => 52,  160 => 76,  137 => 46,  113 => 48,  100 => 43,  90 => 36,  81 => 20,  65 => 29,  129 => 49,  97 => 41,  84 => 36,  77 => 34,  53 => 24,  34 => 16,  23 => 12,  480 => 128,  474 => 285,  469 => 158,  461 => 155,  457 => 135,  453 => 142,  444 => 149,  440 => 131,  437 => 130,  435 => 258,  430 => 130,  427 => 89,  423 => 166,  413 => 100,  409 => 98,  407 => 88,  402 => 130,  398 => 129,  393 => 114,  387 => 122,  384 => 131,  381 => 118,  379 => 127,  374 => 124,  368 => 96,  365 => 95,  362 => 94,  360 => 123,  355 => 124,  341 => 114,  337 => 87,  322 => 101,  314 => 85,  312 => 84,  309 => 76,  305 => 74,  298 => 173,  294 => 83,  285 => 111,  283 => 79,  278 => 74,  268 => 58,  264 => 2,  258 => 72,  252 => 70,  247 => 66,  241 => 77,  229 => 61,  220 => 49,  214 => 99,  177 => 48,  169 => 69,  140 => 97,  132 => 44,  128 => 153,  107 => 46,  61 => 27,  273 => 96,  269 => 75,  254 => 102,  243 => 89,  240 => 65,  238 => 57,  235 => 56,  230 => 61,  227 => 46,  224 => 60,  221 => 67,  219 => 101,  217 => 79,  208 => 124,  204 => 57,  179 => 72,  159 => 39,  143 => 26,  135 => 45,  119 => 149,  102 => 43,  71 => 32,  67 => 32,  63 => 28,  59 => 26,  38 => 19,  94 => 40,  89 => 17,  85 => 36,  75 => 32,  68 => 30,  56 => 25,  201 => 56,  196 => 65,  183 => 50,  171 => 102,  166 => 100,  163 => 68,  158 => 75,  156 => 68,  151 => 36,  142 => 58,  138 => 46,  136 => 156,  121 => 51,  117 => 49,  105 => 45,  91 => 39,  62 => 28,  49 => 23,  26 => 14,  87 => 28,  31 => 15,  28 => 14,  24 => 13,  25 => 13,  21 => 11,  19 => 11,  93 => 39,  88 => 37,  78 => 32,  46 => 22,  44 => 21,  27 => 14,  79 => 34,  72 => 31,  69 => 30,  47 => 25,  40 => 19,  37 => 21,  22 => 12,  246 => 66,  157 => 29,  145 => 53,  139 => 51,  131 => 154,  123 => 52,  120 => 49,  115 => 47,  111 => 43,  108 => 45,  101 => 39,  98 => 42,  96 => 37,  83 => 36,  74 => 33,  66 => 30,  55 => 24,  52 => 23,  50 => 23,  43 => 21,  41 => 20,  35 => 20,  32 => 16,  29 => 15,  209 => 96,  203 => 39,  199 => 67,  193 => 33,  189 => 52,  187 => 87,  182 => 85,  176 => 82,  173 => 71,  168 => 44,  164 => 72,  162 => 40,  154 => 103,  149 => 62,  147 => 52,  144 => 51,  141 => 67,  133 => 155,  130 => 57,  125 => 46,  122 => 150,  116 => 148,  112 => 146,  109 => 108,  106 => 45,  103 => 38,  99 => 42,  95 => 35,  92 => 34,  86 => 37,  82 => 31,  80 => 35,  73 => 34,  64 => 24,  60 => 28,  57 => 27,  54 => 25,  51 => 24,  48 => 25,  45 => 24,  42 => 23,  39 => 18,  36 => 17,  33 => 16,  30 => 13,);
    }
}
