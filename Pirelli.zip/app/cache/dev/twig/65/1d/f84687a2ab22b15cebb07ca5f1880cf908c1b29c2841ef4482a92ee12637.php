<?php

/* CelmediaToyocostaPirelliBundle:Blocks:top.menu.html.twig */
class __TwigTemplate_651df84687a2ab22b15cebb07ca5f1880cf908c1b29c2841ef4482a92ee12637 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "  
  <div class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">


    <div class=\"row\" id=\"linkstop\">
      <div class=\"col-md-12\">
        <div class=\"row pull-right\">
              <div class=\"col-md-12 links\">
                <p class=\"navbar-text\"><a href=\"#\">Regístrese</a> / <a href=\"#\" style=\"\">Iniciar Sesión</a></p>
                <p class=\"navbar-text\"><a href=\"#\">Inicio</a>
                <a href=\"#\">Empresa</a>
                <a href=\"#\">Noticias</a>
                <a href=\"#\">Cita Talleres</a>
                <a href=\"#\">Test Drive</a>
                <a href=\"#\">Trabaje con Nosotros</a>
                <a href=\"#\">Contáctenos</a></p>
                <p class=\"navbar-text\" style=\"margin:0px;\">
                  <a href=\"http://www.facebook.com/toyocosta\" class=\"icon-facebook\" target=\"_blank\"></a>
                </p>
                <p class=\"navbar-text\" style=\"margin:0px;\">
                  <a href=\"http://twitter.com/toyocosta\" class=\"icon-twitter\" target=\"_blank\"></a>
                </p>
                
                
              </div>
          </div>
      </div>
      
    </div>


    <div class=\"row sombra-toyocosta\">
      <div class=\"col-md-2 col-md-offset-2\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
          <span class=\"sr-only\">Toggle navigation</span>
          <span class=\"icon-bar\"></span>
          <span class=\"icon-bar\"></span>
          <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"#\" style=\"padding-left: 60px;\">
            ";
        // line 42
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "61ac2e4_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_61ac2e4_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/61ac2e4_toyocosta_1.png");
            // line 43
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"llanta\" class=\"img-responsive\" />
            ";
        } else {
            // asset "61ac2e4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_61ac2e4") : $this->env->getExtension('assets')->getAssetUrl("_controller/images/61ac2e4.png");
            echo "              <img src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" alt=\"llanta\" class=\"img-responsive\" />
            ";
        }
        unset($context["asset_url"]);
        // line 45
        echo "          </a>
        </div>
        
      </div>
      <div class=\"col-md-8\">
        <div class=\"collapse navbar-collapse pull-right\">

            <ul id=\"nav-principal\" class=\"nav navbar-nav\" style=\"margin-right:0px;\">
              <li class=\"\"><a href=\"#autos\">AUTOS</a></li>
              <li><a href=\"#camio\">CAMIONETAS</a></li>
              <li><a href=\"#suv\">SUV</a></li>
              <li><a href=\"#hibridos\">H&Iacute;BRIDOS</a></li>
              <li><a href=\"#monta\">MONTACARGAS</a></li>
              <li class=\"active\" ><a href=\"#\">PIRELLI</a></li>
              <li><a href=\"#seminuevos\">SEMINUEVOS</a></li>
            </ul>
            <form class=\"form-inline pull-right\" role=\"form\">
              <div class=\"form-group\" style=\"float:left;\">
                <input class=\"form-control input-lg cursiva input-search\" type=\"text\" placeholder=\"Buscar\">
              </div>
              <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-buscar\"></button>
              </div>
              
            </form>
            

        </div>
       
      </div>
    </div>

  </div>";
    }

    public function getTemplateName()
    {
        return "CelmediaToyocostaPirelliBundle:Blocks:top.menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 45,  66 => 43,  62 => 42,  135 => 44,  103 => 43,  98 => 37,  96 => 36,  87 => 29,  84 => 28,  82 => 27,  74 => 21,  36 => 19,  32 => 12,  19 => 1,);
    }
}
