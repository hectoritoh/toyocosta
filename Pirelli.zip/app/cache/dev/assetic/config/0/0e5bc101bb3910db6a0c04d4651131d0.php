<?php

// CelmediaToyocostaPirelliBundle:Pages:pirelli.html.twig
return array (
  'c17ebaf' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/Banners/pirelli-promocional.jpg',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/c17ebaf.jpg',
      'name' => 'c17ebaf',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'bdff3a8' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/llanta.jpg',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/bdff3a8.jpg',
      'name' => 'bdff3a8',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '4b3fede' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/llanta-lightbox.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/4b3fede.png',
      'name' => '4b3fede',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
