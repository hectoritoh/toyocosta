<?php

// CelmediaToyocostaPirelliBundle:Blocks:footer.html.twig
return array (
  'c17ebaf' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/Banners/pirelli-promocional.jpg',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/c17ebaf.jpg',
      'name' => 'c17ebaf',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'bdff3a8' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/llanta.jpg',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/bdff3a8.jpg',
      'name' => 'bdff3a8',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '4b3fede' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/llanta-lightbox.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/4b3fede.png',
      'name' => '4b3fede',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'ca9947f' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/css/bootstrap.min.css',
      1 => '@CelmediaToyocostaPirelliBundle/Resources/public/css/menu.toyocosta.css',
      2 => '@CelmediaToyocostaPirelliBundle/Resources/public/css/jquery.selectbox/jquery.selectbox.css',
      3 => '@CelmediaToyocostaPirelliBundle/Resources/public/css/reset.css',
      4 => '@CelmediaToyocostaPirelliBundle/Resources/public/css/estilo.pirelli.css',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/css/ca9947f.css',
      'name' => 'ca9947f',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '06490c7' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/js/jquery.js',
      1 => '@CelmediaToyocostaPirelliBundle/Resources/public/js/jquery.selectbox/jquery.selectbox-0.2.js',
      2 => '@CelmediaToyocostaPirelliBundle/Resources/public/js/script.js',
      3 => '@CelmediaToyocostaPirelliBundle/Resources/public/js/bootstrap.min.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/06490c7.js',
      'name' => '06490c7',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'bcd6fa0' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/Logos/pirelli.jpg',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/bcd6fa0.jpg',
      'name' => 'bcd6fa0',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'fe7c180' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/Iconos/mas.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/fe7c180.png',
      'name' => 'fe7c180',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '6c29613' => 
  array (
    0 => 
    array (
      0 => '@CelmediaToyocostaPirelliBundle/Resources/public/images/Iconos/cerrar.png',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/images/6c29613.png',
      'name' => '6c29613',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
